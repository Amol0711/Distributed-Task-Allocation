#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
rm -rf "$ROOT/results/generated"
python "$ROOT/scripts/check_environment.py"
python "$ROOT/scripts/verify_reference_results.py"
PYTHONPATH="$ROOT/src" python "$ROOT/tests/test_smoke.py"
python "$ROOT/scripts/run_baselines.py" \
  --partition evaluation --trials-per-campaign 1 --epochs 12 --workers 1
python "$ROOT/scripts/run_exploration.py" \
  --partition evaluation --trials-per-campaign 1 --epochs 12 \
  --c-exp 0.0 0.25 --workers 1
python "$ROOT/scripts/summarize_results.py"
python "$ROOT/scripts/validate_results.py"
printf '%s\n' 'Quick validation completed successfully.'
