#!/usr/bin/env python3
"""Validate generated simulation files and empirical feasibility diagnostics."""
from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]

COMMON_REQUIRED = {
    "schema_version",
    "campaign_id",
    "partition",
    "trial_index",
    "trial_seed",
    "epoch",
    "assignment_valid",
    "resource_violations",
    "complete_family_violations",
    "central_distributed_mismatch",
    "allocation_rounds",
    "round_law_expected",
    "finite_time_envelope_slack",
    "control_limit_margin",
    "model_validity_margin",
}


def number(value: str, *, path: Path, field: str, row_number: int) -> float:
    if value == "":
        return math.nan
    try:
        result = float(value)
    except ValueError as exc:
        raise ValueError(f"{path}: row {row_number}: nonnumeric {field}={value!r}") from exc
    if not math.isfinite(result):
        raise ValueError(f"{path}: row {row_number}: nonfinite {field}={value!r}")
    return result


def integer(value: str, *, path: Path, field: str, row_number: int) -> int:
    result = number(value, path=path, field=field, row_number=row_number)
    if result != int(result):
        raise ValueError(f"{path}: row {row_number}: noninteger {field}={value!r}")
    return int(result)


def validate_file(path: Path) -> dict[str, Any]:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        fields = set(reader.fieldnames or [])
        missing = COMMON_REQUIRED - fields
        if missing:
            raise ValueError(f"{path}: missing fields {sorted(missing)}")
        rows = list(reader)
    if not rows:
        raise ValueError(f"{path}: empty result file")

    schema = rows[0]["schema_version"]
    if schema not in {"baseline-campaign-v1", "exploration-campaign-v1"}:
        raise ValueError(f"{path}: unsupported schema {schema!r}")
    if schema == "baseline-campaign-v1" and "method_id" not in fields:
        raise ValueError(f"{path}: baseline file lacks method_id")
    if schema == "exploration-campaign-v1":
        required = {
            "variant_id",
            "c_exp",
            "cumulative_true_value",
            "cumulative_oracle_value",
            "cumulative_oracle_ratio",
            "realized_exploration_count",
            "bound_arithmetic_holds",
        }
        if required - fields:
            raise ValueError(f"{path}: exploration file lacks {sorted(required - fields)}")

    constants = ("schema_version", "campaign_id", "partition", "trial_index", "trial_seed")
    for field in constants:
        values = {row[field] for row in rows}
        if len(values) != 1:
            raise ValueError(f"{path}: field {field} is not constant")

    epochs = [integer(row["epoch"], path=path, field="epoch", row_number=n) for n, row in enumerate(rows, 2)]
    if epochs != list(range(1, len(rows) + 1)):
        raise ValueError(f"{path}: epochs are not contiguous from one")

    failures: list[str] = []
    previous_true = -math.inf
    previous_reference = -math.inf
    previous_explorations = -1
    for row_number, row in enumerate(rows, 2):
        for field in ("assignment_valid",):
            if integer(row[field], path=path, field=field, row_number=row_number) != 1:
                failures.append(f"row {row_number}: invalid assignment")
        for field in ("resource_violations", "complete_family_violations", "central_distributed_mismatch"):
            if integer(row[field], path=path, field=field, row_number=row_number) != 0:
                failures.append(f"row {row_number}: {field} is nonzero")
        rounds = integer(row["allocation_rounds"], path=path, field="allocation_rounds", row_number=row_number)
        expected = integer(row["round_law_expected"], path=path, field="round_law_expected", row_number=row_number)
        if rounds != expected:
            failures.append(f"row {row_number}: allocation round count mismatch")
        for field in ("finite_time_envelope_slack", "control_limit_margin", "model_validity_margin"):
            value = number(row[field], path=path, field=field, row_number=row_number)
            if value < -1.0e-8:
                failures.append(f"row {row_number}: negative {field}")

        if schema == "exploration-campaign-v1":
            if integer(row["bound_arithmetic_holds"], path=path, field="bound_arithmetic_holds", row_number=row_number) != 1:
                failures.append(f"row {row_number}: cumulative arithmetic check failed")
            current_true = number(row["cumulative_true_value"], path=path, field="cumulative_true_value", row_number=row_number)
            current_reference = number(row["cumulative_oracle_value"], path=path, field="cumulative_oracle_value", row_number=row_number)
            current_explorations = integer(row["realized_exploration_count"], path=path, field="realized_exploration_count", row_number=row_number)
            if current_true + 1.0e-10 < previous_true:
                failures.append(f"row {row_number}: cumulative true value decreased")
            if current_reference + 1.0e-10 < previous_reference:
                failures.append(f"row {row_number}: cumulative reference value decreased")
            if current_explorations < previous_explorations:
                failures.append(f"row {row_number}: exploration count decreased")
            previous_true = current_true
            previous_reference = current_reference
            previous_explorations = current_explorations

    if failures:
        raise ValueError(f"{path}: " + "; ".join(failures[:12]))
    return {
        "path": path.as_posix(),
        "schema_version": schema,
        "rows": len(rows),
        "campaign_id": rows[0]["campaign_id"],
        "trial_index": int(rows[0]["trial_index"]),
        "status": "PASS",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--raw-root",
        type=Path,
        default=ROOT / "results" / "generated" / "raw",
        help="directory containing generated raw CSV files",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results" / "generated" / "validation.json",
        help="machine-readable validation report",
    )
    args = parser.parse_args()
    raw_root = args.raw_root.resolve()
    paths = sorted(raw_root.rglob("*.csv")) if raw_root.exists() else []
    if not paths:
        raise SystemExit(f"no raw CSV files found under {raw_root}")

    records = [validate_file(path) for path in paths]
    for record in records:
        try:
            record["path"] = Path(record["path"]).relative_to(ROOT).as_posix()
        except ValueError:
            pass
    payload = {
        "status": "PASS",
        "files_checked": len(records),
        "rows_checked": sum(record["rows"] for record in records),
        "records": records,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "files_checked": len(records), "rows_checked": payload["rows_checked"]}, sort_keys=True))


if __name__ == "__main__":
    main()
