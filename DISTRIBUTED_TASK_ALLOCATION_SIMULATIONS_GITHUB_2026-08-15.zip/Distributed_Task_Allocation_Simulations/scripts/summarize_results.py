#!/usr/bin/env python3
"""Create compact empirical summaries from generated simulation CSV files."""
from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]

SUMMARY_FIELDS = [
    "record_type",
    "campaign_id",
    "partition",
    "trial_index",
    "trial_seed",
    "method_or_variant",
    "exploration_coefficient",
    "epochs",
    "cumulative_true_value",
    "cumulative_realized_return",
    "cumulative_reference_value",
    "cumulative_reference_ratio",
    "exploration_fraction",
    "terminal_design_min_eigenvalue",
    "mean_tracking_rms",
    "maximum_tracking_peak",
    "resource_violations",
    "family_violations",
    "distributed_mismatches",
    "fallback_episodes",
    "validation_passed",
    "source_file",
]


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError(f"empty raw result file: {path}")
    return rows


def f(value: str | None, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def i(value: str | None, default: int = 0) -> int:
    if value is None or value == "":
        return default
    return int(float(value))


def mean(values: Iterable[float]) -> float:
    values = list(values)
    return sum(values) / len(values) if values else math.nan


def summarize_baseline(path: Path, rows: list[dict[str, str]], raw_root: Path) -> dict[str, object]:
    first, last = rows[0], rows[-1]
    true_total = sum(f(row.get("true_value")) for row in rows)
    return_total = sum(f(row.get("realized_return")) for row in rows)
    reference_total = sum(f(row.get("oracle_greedy_value")) for row in rows)
    ratio = true_total / reference_total if reference_total > 0.0 else 1.0
    violations = sum(i(row.get("resource_violations")) for row in rows)
    family = sum(i(row.get("complete_family_violations")) for row in rows)
    mismatches = sum(i(row.get("central_distributed_mismatch")) for row in rows)
    fallback = sum(i(row.get("fallback_episode")) for row in rows)
    margins_ok = all(
        f(row.get(name), math.inf) >= -1.0e-8
        for row in rows
        for name in (
            "finite_time_envelope_slack",
            "control_limit_margin",
            "model_validity_margin",
        )
    )
    valid = all(i(row.get("assignment_valid")) == 1 for row in rows)
    return {
        "record_type": "baseline",
        "campaign_id": first["campaign_id"],
        "partition": first["partition"],
        "trial_index": i(first["trial_index"]),
        "trial_seed": i(first["trial_seed"]),
        "method_or_variant": first["method_id"],
        "exploration_coefficient": "",
        "epochs": len(rows),
        "cumulative_true_value": true_total,
        "cumulative_realized_return": return_total,
        "cumulative_reference_value": reference_total,
        "cumulative_reference_ratio": ratio,
        "exploration_fraction": 0.0,
        "terminal_design_min_eigenvalue": "",
        "mean_tracking_rms": mean(f(row.get("tracking_rms"), math.nan) for row in rows),
        "maximum_tracking_peak": max(f(row.get("tracking_peak")) for row in rows),
        "resource_violations": violations,
        "family_violations": family,
        "distributed_mismatches": mismatches,
        "fallback_episodes": fallback,
        "validation_passed": int(valid and margins_ok and violations == 0 and family == 0 and mismatches == 0),
        "source_file": path.relative_to(raw_root).as_posix(),
    }


def summarize_exploration(path: Path, rows: list[dict[str, str]], raw_root: Path) -> dict[str, object]:
    first, last = rows[0], rows[-1]
    violations = sum(i(row.get("resource_violations")) for row in rows)
    family = sum(i(row.get("complete_family_violations")) for row in rows)
    mismatches = sum(i(row.get("central_distributed_mismatch")) for row in rows)
    fallback = sum(i(row.get("fallback_episode")) for row in rows)
    margins_ok = all(
        f(row.get(name), math.inf) >= -1.0e-8
        for row in rows
        for name in (
            "finite_time_envelope_slack",
            "control_limit_margin",
            "model_validity_margin",
        )
    )
    valid = all(i(row.get("assignment_valid")) == 1 for row in rows)
    arithmetic = all(i(row.get("bound_arithmetic_holds"), 1) == 1 for row in rows)
    return {
        "record_type": "exploration",
        "campaign_id": first["campaign_id"],
        "partition": first["partition"],
        "trial_index": i(first["trial_index"]),
        "trial_seed": i(first["trial_seed"]),
        "method_or_variant": first["variant_id"],
        "exploration_coefficient": f(first.get("c_exp")),
        "epochs": len(rows),
        "cumulative_true_value": f(last.get("cumulative_true_value")),
        "cumulative_realized_return": sum(f(row.get("realized_return")) for row in rows),
        "cumulative_reference_value": f(last.get("cumulative_oracle_value")),
        "cumulative_reference_ratio": f(last.get("cumulative_oracle_ratio")),
        "exploration_fraction": f(last.get("realized_exploration_count")) / len(rows),
        "terminal_design_min_eigenvalue": f(last.get("design_min_eigenvalue_unregularized")),
        "mean_tracking_rms": mean(f(row.get("tracking_rms"), math.nan) for row in rows),
        "maximum_tracking_peak": max(f(row.get("tracking_peak")) for row in rows),
        "resource_violations": violations,
        "family_violations": family,
        "distributed_mismatches": mismatches,
        "fallback_episodes": fallback,
        "validation_passed": int(valid and arithmetic and margins_ok and violations == 0 and family == 0 and mismatches == 0),
        "source_file": path.relative_to(raw_root).as_posix(),
    }


def render(value: object) -> object:
    if isinstance(value, float):
        if not math.isfinite(value):
            return ""
        return format(value, ".17g")
    return value


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--raw-root",
        type=Path,
        default=ROOT / "results" / "generated" / "raw",
        help="directory containing raw baseline and exploration CSV files",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results" / "generated" / "summary.csv",
        help="summary CSV path",
    )
    args = parser.parse_args()
    raw_root = args.raw_root.resolve()
    paths = sorted(raw_root.rglob("*.csv")) if raw_root.exists() else []
    if not paths:
        raise SystemExit(f"no raw CSV files found under {raw_root}")

    summaries: list[dict[str, object]] = []
    for path in paths:
        rows = read_rows(path)
        schema = rows[0].get("schema_version", "")
        if schema == "baseline-campaign-v1":
            summaries.append(summarize_baseline(path, rows, raw_root))
        elif schema == "exploration-campaign-v1":
            summaries.append(summarize_exploration(path, rows, raw_root))
        else:
            raise ValueError(f"unsupported schema {schema!r} in {path}")

    summaries.sort(
        key=lambda row: (
            str(row["campaign_id"]),
            int(row["trial_index"]),
            str(row["record_type"]),
            str(row["method_or_variant"]),
        )
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=SUMMARY_FIELDS, lineterminator="\n")
        writer.writeheader()
        for row in summaries:
            writer.writerow({key: render(row.get(key, "")) for key in SUMMARY_FIELDS})
    print(f"PASS: wrote {len(summaries)} summary rows to {args.output}")


if __name__ == "__main__":
    main()
