#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
WORKERS="${WORKERS:-4}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
rm -rf "$ROOT/results/generated"
python "$ROOT/scripts/check_environment.py"
python "$ROOT/scripts/verify_reference_results.py"
PYTHONPATH="$ROOT/src" python "$ROOT/tests/test_smoke.py"
python "$ROOT/scripts/run_baselines.py" \
  --partition evaluation --trials-per-campaign 0 --epochs 0 --workers "$WORKERS"
python "$ROOT/scripts/run_exploration.py" \
  --partition evaluation --trials-per-campaign 0 --epochs 0 \
  --c-exp 0.0 0.25 --workers "$WORKERS"
python "$ROOT/scripts/summarize_results.py"
python "$ROOT/scripts/validate_results.py"
printf '%s\n' 'Complete simulation run and validation finished successfully.'
