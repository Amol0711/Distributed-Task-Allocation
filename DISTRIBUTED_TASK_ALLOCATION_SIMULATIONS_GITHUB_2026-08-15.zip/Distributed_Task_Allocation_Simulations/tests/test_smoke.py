from __future__ import annotations

import csv
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from campaign_engine import load_assets, run_trial as run_baseline, sha256_file  # noqa: E402
from exploration_campaign import run_trial as run_exploration  # noqa: E402

CAMPAIGNS = {
    "SAT-COV-V1": ROOT / "configs" / "satellite_campaign.json",
    "UAV-AG-V1": ROOT / "configs" / "uav_campaign.json",
}


class SimulationSmokeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        with (ROOT / "seeds" / "trials.csv").open(newline="", encoding="utf-8") as handle:
            cls.seeds = list(csv.DictReader(handle))
        cls.exploration_config = json.loads((ROOT / "configs" / "exploration.json").read_text(encoding="utf-8"))

    def seed(self, campaign_id: str) -> dict[str, str]:
        return next(
            row
            for row in self.seeds
            if row["campaign_id"] == campaign_id
            and row["partition"] == "evaluation"
            and int(row["trial_index"]) == 1
        )

    @staticmethod
    def stable(result: dict) -> dict:
        result = json.loads(json.dumps(result))
        result.pop("elapsed_seconds", None)
        result.pop("files", None)
        return result

    def test_inputs_load(self) -> None:
        self.assertEqual({row["campaign_id"] for row in self.seeds}, set(CAMPAIGNS))
        for campaign_id, path in CAMPAIGNS.items():
            assets = load_assets(ROOT, path)
            self.assertEqual(assets.cfg["campaign_id"], campaign_id)
            self.assertGreater(len(assets.tracking.modes), 0)
            self.assertGreater(int(assets.cfg["primary"]["epochs"]), 0)

    def test_baseline_is_deterministic_and_feasible(self) -> None:
        engine_hash = sha256_file(ROOT / "src" / "campaign_engine.py")
        for campaign_id, path in CAMPAIGNS.items():
            seed = self.seed(campaign_id)
            with tempfile.TemporaryDirectory() as first, tempfile.TemporaryDirectory() as second:
                kwargs = dict(
                    sim_root=ROOT,
                    campaign_path=path,
                    seed_row=seed,
                    engine_hash=engine_hash,
                    scale="primary",
                    methods=("INSTANTANEOUS_MYOPIC",),
                    epoch_limit=4,
                    write_raw=False,
                )
                result_a = run_baseline(raw_dir=Path(first), **kwargs)
                result_b = run_baseline(raw_dir=Path(second), **kwargs)
            self.assertEqual(self.stable(result_a), self.stable(result_b))
            metrics = result_a["aggregates"]["INSTANTANEOUS_MYOPIC"]
            self.assertEqual(metrics["resource_violations"], 0)
            self.assertEqual(metrics["family_violations"], 0)
            self.assertEqual(metrics["mismatches"], 0)
            self.assertGreater(metrics["mean_oracle_ratio"], 0.0)

    def test_exploration_is_deterministic_and_feasible(self) -> None:
        engine_hash = sha256_file(ROOT / "src" / "exploration_campaign.py")
        config_hash = sha256_file(ROOT / "configs" / "exploration.json")
        seed_hash = sha256_file(ROOT / "seeds" / "trials.csv")
        for campaign_id, path in CAMPAIGNS.items():
            seed = self.seed(campaign_id)
            with tempfile.TemporaryDirectory() as first, tempfile.TemporaryDirectory() as second:
                kwargs = dict(
                    sim_root=ROOT,
                    campaign_path=path,
                    experiment_config=self.exploration_config,
                    seed_row=seed,
                    engine_hash=engine_hash,
                    experiment_config_hash=config_hash,
                    seed_registry_hash=seed_hash,
                    c_values=(0.0, 0.25),
                    epoch_limit=4,
                    write_raw=False,
                )
                result_a = run_exploration(raw_dir=Path(first), **kwargs)
                result_b = run_exploration(raw_dir=Path(second), **kwargs)
            self.assertEqual(self.stable(result_a), self.stable(result_b))
            for metrics in result_a["aggregates"].values():
                self.assertEqual(metrics["resource_violations"], 0)
                self.assertEqual(metrics["family_violations"], 0)
                self.assertEqual(metrics["mismatches"], 0)
                self.assertEqual(metrics["bound_failures"], 0)
                self.assertEqual(metrics["audit_feasibility_failures"], 0)
                self.assertEqual(metrics["audit_mismatches"], 0)
                self.assertGreater(metrics["cumulative_oracle_ratio"], 0.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
