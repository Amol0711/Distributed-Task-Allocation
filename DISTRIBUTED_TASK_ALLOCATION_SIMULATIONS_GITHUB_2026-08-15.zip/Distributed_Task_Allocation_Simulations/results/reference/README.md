# Reference results

This directory contains compact empirical CSV summaries from the deterministic
simulation campaigns. The files report campaign performance, scenario and
learning settings, exploration trade-offs, empirical covariance statistics,
and distributed coordination diagnostics.

Run `python scripts/verify_reference_results.py` to check file integrity and
basic schema requirements. The corresponding hashes and row counts are stored
in `MANIFEST.json`.
